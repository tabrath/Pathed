﻿using Microsoft.WindowsAPICodePack.Dialogs;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Pathed.Services
{
    [Export(typeof(IDialogService)), PartCreationPolicy(CreationPolicy.Shared)]
    public class DialogService : IDialogService
    {
        [ImportingConstructor]
        public DialogService() { }

        public string ShowBrowseFolderDialog()
        {
            string folder = String.Empty;
            using (var dialog = new CommonOpenFileDialog() { EnsurePathExists = true, IsFolderPicker = true })
            {
                if (dialog.ShowDialog(Application.Current.MainWindow) == CommonFileDialogResult.Ok)
                {
                    folder = dialog.FileName;
                }
            }

            return folder;
        }

        public void ShowErrorMessage(string message)
        {
            MessageBox.Show(message);
        }
    }
}
