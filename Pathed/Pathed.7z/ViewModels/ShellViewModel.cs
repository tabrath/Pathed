﻿using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Pathed.Services;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Diagnostics;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;

namespace Pathed.ViewModels
{
    [Export, PartCreationPolicy(CreationPolicy.Shared)]
    public class ShellViewModel : ViewModelBase
    {
        // TODO: impl. EnvironmentViewModel { Paths: IEnumerable<PathViewModel> }

        private EnvironmentVariableTarget target = EnvironmentVariableTarget.User;
        public EnvironmentVariableTarget Target
        {
            get { return this.target; }
            set
            {
                if (this.target != value)
                {
                    this.target = value;

                    RaisePropertyChanged();
                    RaisePropertyChanged("HasAccess");
                    RaisePropertyChanged("HaveNoAccess");

                    GetPathsAsync();
                }
            }
        }

        public string PathEnvironmentVariable
        {
            get { return string.Join(";", this.paths.Select(x => x.Value)); }
        }

        private bool isDirty = false;
        public bool IsDirty
        {
            get { return this.isDirty; }
            set
            {
                if (this.isDirty != value)
                {
                    this.isDirty = value;

                    RaisePropertyChanged();

                    if (this.revertChangesCommand != null)
                        this.revertChangesCommand.RaiseCanExecuteChanged();

                    if (this.saveCommand != null)
                        this.saveCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public bool HasAccess
        {
            get { return (Target == EnvironmentVariableTarget.Machine) ? IsAdministrator() : true; }
        }

        public bool HaveNoAccess
        {
            get { return !HasAccess; }
        }

        private ObservableCollection<PathViewModel> paths;
        private Object pathsLock = new Object();
        public ICollectionView Paths { get; protected set; }

        private IDialogService dialogService;

        private ObservableCollection<PathViewModel> selectedPaths;

        public RelayCommand<IList> SelectionChangedCommand { get; protected set; }

        [ImportingConstructor]
        public ShellViewModel(IDialogService dialogService)
        {
            this.dialogService = dialogService;

            var args = Environment.GetCommandLineArgs();
            if (args.Length > 1)
            {                
                Enum.TryParse<EnvironmentVariableTarget>(args[1], out this.target);
            }

            this.paths = new ObservableCollection<PathViewModel>();
            this.paths.CollectionChanged += (s, e) =>
            {
                RaisePropertyChanged("PathEnvironmentVariable");
                IsDirty = true;
            };
            BindingOperations.EnableCollectionSynchronization(this.paths, this.pathsLock);
            Paths = CollectionViewSource.GetDefaultView(this.paths);
            Paths.SortDescriptions.Add(new SortDescription("Value", ListSortDirection.Ascending));

            this.selectedPaths = new ObservableCollection<PathViewModel>();
            this.selectedPaths.CollectionChanged += (s, e) => { if (this.removeCommand != null) this.removeCommand.RaiseCanExecuteChanged(); };
            SelectionChangedCommand = new RelayCommand<IList>((items) => this.selectedPaths.Update(items.Cast<PathViewModel>()));

            GetPathsAsync();
        }

        private async Task GetPathsAsync()
        {
            this.paths.Update(await GetPathsAsync(this.target));

            IsDirty = false;
        }

        private RelayCommand removeCommand;
        public ICommand RemoveCommand
        {
            get { return this.removeCommand ?? (this.removeCommand = new RelayCommand(Remove, () => this.selectedPaths.Count > 0)); }
        }

        public void Remove()
        {
            this.paths.Remove(this.selectedPaths);
        }

        private RelayCommand removeNotExistingCommand;
        public ICommand RemoveNotExistingCommand
        {
            get { return this.removeNotExistingCommand ?? (this.removeNotExistingCommand = new RelayCommand(RemoveNotExisting, () => this.paths.Where(x => !x.Exists).Count() > 0)); }
        }

        public void RemoveNotExisting()
        {
            this.paths.Remove(this.paths.Where(x => !x.Exists));
        }

        private RelayCommand addCommand;
        public ICommand AddCommand
        {
            get { return this.addCommand ?? (this.addCommand = new RelayCommand(Add)); }
        }

        public void Add()
        {
            string path = this.dialogService.ShowBrowseFolderDialog();
            if (!String.IsNullOrEmpty(path))
            {
                if (!this.paths.Any(x => x.Value.Equals(path, StringComparison.InvariantCultureIgnoreCase)))
                {
                    this.paths.Add(new PathViewModel(path, false));
                } 
                else
                {
                    this.dialogService.ShowErrorMessage("Path already exists.");
                }
            }
        }

        private RelayCommand revertChangesCommand;
        public ICommand RevertChangesCommand
        {
            get
            {
                return this.revertChangesCommand ?? (this.revertChangesCommand = new RelayCommand(async () => { await GetPathsAsync(); }, () => IsDirty));
            }
        }

        private RelayCommand saveCommand;
        public ICommand SaveCommand
        {
            get
            {
                return this.saveCommand ?? (this.saveCommand = new RelayCommand(async () => { await SaveAsync(); }, () => IsDirty));
            }
        }

        public async Task SaveAsync()
        {
            await SetPathsAsync(this.paths, this.target);

            foreach (var path in this.paths.Where(x => !x.IsSet))
            {
                path.IsSet = true;
            }

            IsDirty = false;
        }

        private static Task<IEnumerable<PathViewModel>> GetPathsAsync(EnvironmentVariableTarget target)
        {
            return Task.Factory.StartNew<IEnumerable<PathViewModel>>(() =>
                {
                    return Environment.GetEnvironmentVariable("PATH", target).Split(';').OrderBy(x => x).Select(x => new PathViewModel(x));
                });
        }

        private static Task SetPathsAsync(IEnumerable<PathViewModel> paths, EnvironmentVariableTarget target)
        {
            return Task.Factory.StartNew(() =>
                {
                    Environment.SetEnvironmentVariable("PATH", string.Join(";", paths.OrderBy(x => x.Value).Select(x => x.Value)), target);
                });
        }

        private RelayCommand elevateCommand;
        public ICommand ElevateCommand
        {
            get
            {
                return this.elevateCommand ?? (this.elevateCommand = new RelayCommand(Elevate, () => !IsAdministrator()));
            }
        }

        public void Elevate()
        {
            var exeName = System.Diagnostics.Process.GetCurrentProcess().MainModule.FileName;
            ProcessStartInfo startInfo = new ProcessStartInfo(exeName);
            startInfo.Verb = "runas";
            startInfo.Arguments = this.target.ToString();
            System.Diagnostics.Process.Start(startInfo);
            Application.Current.Shutdown();
        }

        private bool IsAdministrator()
        {
            return new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator);
        }

        private RelayCommand<PathViewModel> openCommand;
        public ICommand OpenCommand
        {
            get
            {
                return this.openCommand ?? (this.openCommand = new RelayCommand<PathViewModel>(Open, x => x != null && x.Exists));
            }
        }

        public void Open(PathViewModel path)
        {
            Process.Start(path.Value);
        }
    }
}
